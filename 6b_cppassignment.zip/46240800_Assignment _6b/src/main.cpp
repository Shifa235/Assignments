
#include <wordset.h>	 

        
int main(int argc,char* argv[])
{
	Wordset w;
	string s;
      
 	vector <string> vlist;
	cout <<"You have entered " << argc<<" arguments:" <<"\n";      
	for (int i = 1; i < argc; ++i)
	{
	 w.addmember(argv[i]);

 	vlist.push_back(argv[i]);
	cout << argv[i] <<"\n";
 	}
       
       
	cout<<"Enter the member you want to Delete"<<endl;
	cin>>s; 
       

	w.displaylist();
       

}
